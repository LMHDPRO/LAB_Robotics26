import sys
from pymodbus.client import ModbusTcpClient

# IP por defecto para Robot 4
target_ip = sys.argv[1] if len(sys.argv) > 1 else "10.110.20.4"
port = 502

print(f"--- PRE-FLIGHT TEST: Conectando a UR3e Robot 4 ({target_ip}:{port}) ---")
client = ModbusTcpClient(target_ip, port=port)

if client.connect():
    print("[OK] Conexión Modbus TCP establecida exitosamente por el puerto 502.")
    
    # 1. Leer Robot_Mode (Offset 258, FC03 - Read Holding Registers)
    res_mode = client.read_holding_registers(address=258, count=1)
    if not res_mode.isError():
        mode = res_mode.registers[0]
        state_str = "7 = RUNNING (Frenos liberados)" if mode == 7 else f"Modo actual = {mode} (Requiere Mode=7)"
        print(f"[OK] Robot Mode (Reg 258): {mode} -> {state_str}")
    else:
        print("[ERROR] Fallo al leer Robot Mode (Reg 258).")
        
    # 2. Leer Robot_Status (Offset 129, FC03)
    res_status = client.read_holding_registers(address=129, count=1)
    if not res_status.isError():
        print(f"[OK] Robot Status (Reg 129): {res_status.registers[0]}")
    else:
        print("[ERROR] Fallo al leer Robot Status (Reg 129).")

    # 3. Leer PLC_Command (Offset 128, FC03)
    res_cmd = client.read_holding_registers(address=128, count=1)
    if not res_cmd.isError():
        print(f"[OK] PLC Command (Reg 128): {res_cmd.registers[0]}")
    else:
        print("[ERROR] Fallo al leer PLC Command (Reg 128).")

    client.close()
    print("--- Diagnóstico finalizado correctamente ---")
else:
    print(f"[FALLO] No se pudo conectar a {target_ip}. Revisa la IP, el cable Ethernet y el puerto 502.")

